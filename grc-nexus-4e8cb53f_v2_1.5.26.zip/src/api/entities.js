import { base44 } from './base44Client';


export const Risk = base44.entities.Risk;

export const Compliance = base44.entities.Compliance;

export const Control = base44.entities.Control;

export const Audit = base44.entities.Audit;

export const RiskAssessment = base44.entities.RiskAssessment;

export const ControlLibrary = base44.entities.ControlLibrary;

export const RiskLibrary = base44.entities.RiskLibrary;

export const KeyIndicator = base44.entities.KeyIndicator;

export const Guidance = base44.entities.Guidance;

export const Notification = base44.entities.Notification;

export const NotificationPreference = base44.entities.NotificationPreference;

export const ReportTemplate = base44.entities.ReportTemplate;

export const ScheduledReport = base44.entities.ScheduledReport;

export const DashboardWidget = base44.entities.DashboardWidget;

export const Incident = base44.entities.Incident;

export const AssessmentTemplate = base44.entities.AssessmentTemplate;

export const AuditProgram = base44.entities.AuditProgram;

export const AuditWorkpaper = base44.entities.AuditWorkpaper;

export const AuditFinding = base44.entities.AuditFinding;

export const RegulatoryExam = base44.entities.RegulatoryExam;

export const UserProgress = base44.entities.UserProgress;

export const Challenge = base44.entities.Challenge;

export const QuestionBank = base44.entities.QuestionBank;

export const MitigationAction = base44.entities.MitigationAction;

export const ControlTest = base44.entities.ControlTest;

export const ControlWorkflow = base44.entities.ControlWorkflow;

export const ControlTestSchedule = base44.entities.ControlTestSchedule;

export const RemediationTask = base44.entities.RemediationTask;

export const AutomationTask = base44.entities.AutomationTask;

export const AutomationRule = base44.entities.AutomationRule;

export const Comment = base44.entities.Comment;

export const Task = base44.entities.Task;

export const Vendor = base44.entities.Vendor;

export const VendorAssessment = base44.entities.VendorAssessment;

export const VendorAudit = base44.entities.VendorAudit;

export const VendorAuditTask = base44.entities.VendorAuditTask;

export const VendorAuditTemplate = base44.entities.VendorAuditTemplate;

export const VendorOnboardingTask = base44.entities.VendorOnboardingTask;

export const VendorPerformanceMetric = base44.entities.VendorPerformanceMetric;

export const VendorKPI = base44.entities.VendorKPI;

export const VendorSLA = base44.entities.VendorSLA;

export const VendorReview = base44.entities.VendorReview;

export const VendorDocument = base44.entities.VendorDocument;

export const FrameworkMapping = base44.entities.FrameworkMapping;

export const UserDashboardPreference = base44.entities.UserDashboardPreference;

export const Role = base44.entities.Role;

export const UserRole = base44.entities.UserRole;

export const Client = base44.entities.Client;

export const ClientDocument = base44.entities.ClientDocument;

export const SecurityEvent = base44.entities.SecurityEvent;

export const AuditLog = base44.entities.AuditLog;

export const TrainingProgress = base44.entities.TrainingProgress;

export const PrivacyAssessment = base44.entities.PrivacyAssessment;

export const DataProcessingActivity = base44.entities.DataProcessingActivity;

export const DataSubjectRequest = base44.entities.DataSubjectRequest;

export const Threat = base44.entities.Threat;

export const Vulnerability = base44.entities.Vulnerability;

export const ThreatAssessment = base44.entities.ThreatAssessment;



// auth sdk:
export const User = base44.auth;